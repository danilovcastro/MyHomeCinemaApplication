namespace HomeCinema.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial_migration1 : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Customer", "LastName");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Customer", "LastName", c => c.String(nullable: false, maxLength: 100));
        }
    }
}
