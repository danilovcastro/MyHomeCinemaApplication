﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeCinema.Entities;

namespace HomeCinema.Data.Configuration
{
    public class UserConfiguration : EntityBaseConfiguration<User>
    {
        public UserConfiguration()
        {
            Property(e => e.UserName).IsRequired().HasMaxLength(100);
            Property(e => e.Email).IsRequired().HasMaxLength(200);
            Property(e => e.HashedPassword).IsRequired().HasMaxLength(200);
            Property(e => e.DateCreated).IsRequired();
        }
    }
}
