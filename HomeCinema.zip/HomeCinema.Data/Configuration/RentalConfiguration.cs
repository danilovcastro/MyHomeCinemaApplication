﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeCinema.Entities;

namespace HomeCinema.Data.Configuration
{
    public class RentalConfiguration : EntityBaseConfiguration<Rental>
    {
        public RentalConfiguration()
        {
            Property(e => e.CustomerId).IsRequired();
            Property(e => e.StockId).IsRequired();
            Property(e => e.Status).IsRequired().HasMaxLength(10);
            Property(e => e.ReturnedDate).IsOptional();
        }
    }
}
