﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeCinema.Entities;

namespace HomeCinema.Data.Configuration
{
    public class MovieConfiguration : EntityBaseConfiguration<Movie>
    {
        public MovieConfiguration()
        {
            Property(e => e.Title).IsRequired().HasMaxLength(100);
            Property(e => e.Description).IsRequired().HasMaxLength(2000);
            Property(e => e.GenreId).IsRequired();
            Property(e => e.ReleaseDate).IsRequired();
            Property(e => e.Rate).IsRequired();
            HasMany(e => e.Stocks).WithRequired().HasForeignKey(s => s.MovieId);
        }
    }
}
