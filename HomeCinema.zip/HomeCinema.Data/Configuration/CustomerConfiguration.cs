﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeCinema.Entities;

namespace HomeCinema.Data.Configuration
{
    public class CustomerConfiguration : EntityBaseConfiguration<Customer>
    {
        public CustomerConfiguration()
        {
            Property(e => e.FirstName).IsRequired().HasMaxLength(100);
            Property(e => e.LastName).IsRequired().HasMaxLength(100);
            Property(e => e.UniqueKey).IsRequired();
            Property(e => e.Email).IsRequired().HasMaxLength(200);
            Property(e => e.RegistrationDate).IsRequired();
        }
    }
}