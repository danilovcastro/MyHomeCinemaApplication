﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeCinema.Entities;

namespace HomeCinema.Data.Configuration
{
    public class StockConfiguration : EntityBaseConfiguration<Stock>
    {
        public StockConfiguration()
        {
            Property(e => e.MovieId).IsRequired();
            Property(e => e.UniqueKey).IsRequired();
            Property(e => e.IsAvailable).IsRequired();
            HasMany(e => e.Rentals).WithRequired(e => e.Stock).HasForeignKey(e => e.StockId);
        }
    }
}
